# Histo Quest — proyecto Android

Primera versión de una aplicación educativa de aventura para Android.

## Requisitos
- Android Studio (versión reciente)
- JDK 17
- Android SDK Platform 35

## Abrir y generar APK
1. Descomprime `HistoQuestAndroid.zip`.
2. Abre la carpeta `HistoQuestAndroid` desde Android Studio.
3. Espera a que termine la sincronización de Gradle.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio generará el APK en `app/build/outputs/apk/debug/app-debug.apk`.
6. Copia ese APK a tu teléfono e instálalo. Si Android lo solicita, autoriza la instalación desde esa fuente.

## Contenido
- Aplicación Android nativa contenedora (Kotlin + WebView local).
- Juego HTML/CSS/JavaScript sin conexión a internet.
- Cuatro mundos: ocular, auditivo, reproductor masculino y femenino.
- Preguntas, puntuación, vidas, desbloqueo y progreso local.

## Nota
Esta entrega es el **proyecto fuente**, no un APK ya compilado. Para obtener el APK hay que compilarlo con Android Studio y el Android SDK.
